import uvicorn

if __name__ == "__main__":
    uvicorn.run("unified_engine.api:app", host="0.0.0.0", port=8000, reload=False)
