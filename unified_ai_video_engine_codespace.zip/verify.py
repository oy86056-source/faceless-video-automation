from unified_engine.director import UnifiedDirector

d = UnifiedDirector()
checks = d.verify_core()
print("\n=== UNIFIED ENGINE VERIFICATION ===")
for name, ok in checks.items():
    state = d.status.items[name].state.value
    mark = "✓" if state == "ACTIVE" else "!"
    print(f"[{mark}] {name}: {state}")
print("\nStatus file: runtime/status.json")
