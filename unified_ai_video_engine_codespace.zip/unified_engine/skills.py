from __future__ import annotations
from pathlib import Path
from .status import StatusRegistry, State

class SkillRegistry:
    def __init__(self, status: StatusRegistry, root="skills"):
        self.root = Path(root)
        self.status = status

    def discover(self):
        self.root.mkdir(parents=True, exist_ok=True)
        return sorted(p.name for p in self.root.iterdir() if p.is_dir())

    def verify(self):
        self.discover()
        self.status.set("skill_registry", State.ACTIVE, "Filesystem skill registry verified")
        return True
