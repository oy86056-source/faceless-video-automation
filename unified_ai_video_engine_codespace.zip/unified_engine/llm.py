from __future__ import annotations
import os
import httpx
from .status import StatusRegistry, State

class LLMRouter:
    # OpenAI-compatible gateway adapter. Point this at FreeLLMAPI, BlockRun,
    # or another compatible gateway without coupling the core to one provider.
    def __init__(self, status: StatusRegistry):
        self.base_url = os.getenv("LLM_BASE_URL", "").rstrip("/")
        self.api_key = os.getenv("LLM_API_KEY", "")
        self.model = os.getenv("LLM_MODEL", "")
        self.status = status

    async def generate(self, prompt: str) -> str:
        if not self.base_url or not self.model:
            raise RuntimeError("LLM_BASE_URL and LLM_MODEL are required for live generation")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        payload = {"model": self.model, "messages": [{"role":"user","content":prompt}]}
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
        return data["choices"][0]["message"]["content"]

    async def verify(self) -> bool:
        if not self.base_url or not self.model:
            self.status.set("llm_router", State.APPLIED, "Adapter installed; live endpoint not configured")
            return False
        try:
            await self.generate("Reply with exactly: ACTIVE")
            self.status.set("llm_router", State.ACTIVE, "Live OpenAI-compatible endpoint verified")
            return True
        except Exception as e:
            self.status.set("llm_router", State.FAILED, str(e))
            return False
