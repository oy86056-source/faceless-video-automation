from fastapi import FastAPI
from .director import UnifiedDirector
from .models import StoryRequest

app = FastAPI(title="Unified AI Video Engine", version="0.1.0")
director = UnifiedDirector()

@app.get("/health")
def health():
    return {"ok": True, "service": "unified-ai-video-engine"}

@app.get("/status")
def status():
    return director.status_report()

@app.post("/verify")
def verify():
    return director.verify_core()

@app.post("/jobs")
def create_job(req: StoryRequest):
    return director.create_job(req).model_dump()
