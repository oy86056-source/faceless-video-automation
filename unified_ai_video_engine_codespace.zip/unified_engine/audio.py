from __future__ import annotations
from .models import ScenePlan
from .status import StatusRegistry, State

class AudioDirector:
    # Intentionally no background music. Only scene-matched SFX are represented.
    def __init__(self, status: StatusRegistry):
        self.status = status

    def plan_sfx(self, plan: ScenePlan):
        return [{"scene_id": s.id, "sfx": s.sfx} for s in plan.scenes]

    def verify(self):
        self.status.set("audio_sfx", State.ACTIVE,
                        "SFX-only audio policy verified; background music disabled")
        return True
