from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
import json

class State(str, Enum):
    DISCOVERED = "DISCOVERED"
    ADAPTED = "ADAPTED"
    APPLIED = "APPLIED"
    TESTED = "TESTED"
    ACTIVE = "ACTIVE"
    FAILED = "FAILED"

@dataclass
class ComponentStatus:
    name: str
    state: State
    detail: str = ""
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class StatusRegistry:
    def __init__(self, path: str = "runtime/status.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.items: dict[str, ComponentStatus] = {}
        self.load()

    def load(self):
        if self.path.exists():
            raw = json.loads(self.path.read_text())
            self.items = {
                k: ComponentStatus(k, State(v["state"]), v.get("detail",""), v.get("checked_at",""))
                for k,v in raw.items()
            }

    def set(self, name: str, state: State, detail: str = ""):
        self.items[name] = ComponentStatus(name, state, detail)
        self.save()

    def save(self):
        self.path.write_text(json.dumps({
            k: {"state": v.state.value, "detail": v.detail, "checked_at": v.checked_at}
            for k,v in self.items.items()
        }, indent=2))

    def active(self, name: str):
        return self.items.get(name) and self.items[name].state == State.ACTIVE
