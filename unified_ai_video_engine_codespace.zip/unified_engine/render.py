from __future__ import annotations
import shutil, subprocess
from pathlib import Path
from .status import StatusRegistry, State

class RenderEngine:
    def __init__(self, status: StatusRegistry):
        self.status = status

    def ffmpeg_available(self):
        return shutil.which("ffmpeg") is not None

    def verify(self):
        ok = self.ffmpeg_available()
        self.status.set("renderer", State.ACTIVE if ok else State.APPLIED,
                        "FFmpeg detected" if ok else "FFmpeg adapter installed; binary not detected")
        return ok
