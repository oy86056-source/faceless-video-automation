from __future__ import annotations
import re
from .models import Scene, ScenePlan
from .status import StatusRegistry, State

class SceneDirector:
    def __init__(self, status: StatusRegistry):
        self.status = status

    def plan(self, idea: str, target_seconds: int) -> ScenePlan:
        # Deterministic fallback planner. A live LLM can replace this method.
        chunks = [x.strip() for x in re.split(r"(?<=[.!?])\s+", idea) if x.strip()]
        if not chunks:
            chunks = [idea]
        duration = max(3.0, target_seconds / len(chunks))
        scenes = []
        for i, chunk in enumerate(chunks, 1):
            scenes.append(Scene(
                id=f"SCENE-{i:03d}",
                title=f"Scene {i}",
                description=chunk,
                duration=duration,
                visual_prompt=chunk,
                motion_mode="IMAGE_TO_VIDEO",
                sfx=[]
            ))
        return ScenePlan(scenes=scenes)

    def verify(self):
        plan = self.plan("A test event happens. The consequence is revealed.", 10)
        ok = len(plan.scenes) >= 2 and all(s.duration > 0 for s in plan.scenes)
        self.status.set("scene_director", State.ACTIVE if ok else State.FAILED,
                        "Scene planning verification")
        return ok
