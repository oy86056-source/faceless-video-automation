from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Any

class StoryRequest(BaseModel):
    idea: str = Field(min_length=1)
    target_seconds: int = Field(default=60, ge=1)
    aspect_ratio: str = "16:9"

class Scene(BaseModel):
    id: str
    title: str
    description: str
    duration: float = Field(gt=0)
    visual_prompt: str = ""
    motion_mode: str = "IMAGE_TO_VIDEO"
    sfx: list[str] = []

class ScenePlan(BaseModel):
    scenes: list[Scene]

class JobResult(BaseModel):
    ok: bool
    job_id: str
    state: str
    output: str | None = None
    details: dict[str, Any] = {}
