from __future__ import annotations
from pathlib import Path
from .models import ScenePlan
from .status import StatusRegistry, State

class GenerationAdapter:
    # Provider-neutral adapter. A Wan2GP/headless service can be connected here.
    def __init__(self, status: StatusRegistry, output_dir="runtime/generated"):
        self.status = status
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def build_jobs(self, plan: ScenePlan):
        return [{"scene_id": s.id, "mode": s.motion_mode, "prompt": s.visual_prompt}
                for s in plan.scenes]

    def verify(self):
        self.build_jobs(ScenePlan(scenes=[]))
        self.status.set("generation_adapter", State.ACTIVE,
                        "Provider-neutral generation adapter verified")
        return True
