from __future__ import annotations
import uuid, json
from pathlib import Path
from .status import StatusRegistry, State
from .models import StoryRequest, JobResult
from .scenes import SceneDirector
from .generation import GenerationAdapter
from .audio import AudioDirector
from .agents import AgentOrchestrator
from .skills import SkillRegistry
from .render import RenderEngine

class UnifiedDirector:
    def __init__(self):
        self.status = StatusRegistry()
        self.agents = AgentOrchestrator(self.status)
        self.skills = SkillRegistry(self.status)
        self.scenes = SceneDirector(self.status)
        self.generation = GenerationAdapter(self.status)
        self.audio = AudioDirector(self.status)
        self.render = RenderEngine(self.status)

    def verify_core(self):
        checks = {
            "agent_orchestrator": self.agents.verify(),
            "skill_registry": self.skills.verify(),
            "scene_director": self.scenes.verify(),
            "generation_adapter": self.generation.verify(),
            "audio_sfx": self.audio.verify(),
        }
        # Renderer can legitimately remain APPLIED when FFmpeg is unavailable.
        checks["renderer"] = self.render.verify()
        core_ok = all(checks[k] for k in ["agent_orchestrator","skill_registry",
                                          "scene_director","generation_adapter","audio_sfx"])
        self.status.set("unified_core", State.ACTIVE if core_ok else State.FAILED,
                        "Core verification completed")
        return checks

    def create_job(self, req: StoryRequest):
        job_id = uuid.uuid4().hex[:12]
        plan = self.scenes.plan(req.idea, req.target_seconds)
        jobs = self.generation.build_jobs(plan)
        sfx = self.audio.plan_sfx(plan)
        Path("runtime/jobs").mkdir(parents=True, exist_ok=True)
        Path(f"runtime/jobs/{job_id}.json").write_text(json.dumps({
            "job_id": job_id,
            "request": req.model_dump(),
            "scenes": plan.model_dump(),
            "generation_jobs": jobs,
            "audio": sfx
        }, indent=2))
        return JobResult(ok=True, job_id=job_id, state="PLANNED",
                         details={"scene_count": len(plan.scenes)})

    def status_report(self):
        return {k: {"state": v.state.value, "detail": v.detail, "checked_at": v.checked_at}
                for k,v in self.status.items.items()}
