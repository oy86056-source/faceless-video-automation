from __future__ import annotations
from dataclasses import dataclass
from .status import StatusRegistry, State

@dataclass
class Agent:
    name: str
    role: str

class AgentOrchestrator:
    # Clean-room orchestration layer: mailbox/routing concepts are represented
    # without depending on an Electron desktop runtime.
    def __init__(self, status: StatusRegistry):
        self.status = status
        self.agents = [
            Agent("director", "coordinates the production"),
            Agent("story", "story and scene planning"),
            Agent("visual", "visual/motion decisions"),
            Agent("audio", "SFX decisions"),
            Agent("qa", "verification"),
        ]
        self.mailbox: list[dict] = []

    def route(self, task: str) -> Agent:
        t = task.lower()
        if "audio" in t or "sfx" in t:
            return self.agents[3]
        if "visual" in t or "scene" in t:
            return self.agents[2]
        if "test" in t or "verify" in t:
            return self.agents[4]
        if "story" in t:
            return self.agents[1]
        return self.agents[0]

    def send(self, task: str, payload: dict):
        agent = self.route(task)
        msg = {"to": agent.name, "task": task, "payload": payload}
        self.mailbox.append(msg)
        return msg

    def verify(self):
        self.status.set("agent_orchestrator", State.ACTIVE,
                        f"{len(self.agents)} agents and in-process mailbox verified")
        return True
