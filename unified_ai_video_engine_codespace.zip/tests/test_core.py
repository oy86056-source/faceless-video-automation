from unified_engine.director import UnifiedDirector
from unified_engine.models import StoryRequest

def test_core_components():
    d = UnifiedDirector()
    checks = d.verify_core()
    assert checks["agent_orchestrator"]
    assert checks["skill_registry"]
    assert checks["scene_director"]
    assert checks["generation_adapter"]
    assert checks["audio_sfx"]
    assert d.status.items["unified_core"].state.value == "ACTIVE"

def test_job_creation():
    d = UnifiedDirector()
    result = d.create_job(StoryRequest(idea="A man receives a call from his own number."))
    assert result.ok
    assert result.state == "PLANNED"
    assert result.details["scene_count"] >= 1
