# Unified AI Video Engine

A modular Codespaces-ready integration layer inspired by the audited capabilities of
FreeLLMAPI, Flick, Wan2GP, Munder Difflin, and Anthropic Skills.

Important: this project does NOT copy third-party repositories wholesale. It provides
clean interfaces/adapters so each capability can be connected and verified independently.

Lifecycle:
DISCOVERED -> ADAPTED -> APPLIED -> TESTED -> ACTIVE

The ACTIVE state is only written after the component's verification check succeeds.
